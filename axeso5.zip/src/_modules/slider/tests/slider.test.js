'use strict';

var Slider = require('../slider');

describe('Slider View', function() {

  beforeEach(function() {
    this.slider = new Slider();
  });

  it('Should run a few assertions', function() {
    expect(this.slider);
  });

});
