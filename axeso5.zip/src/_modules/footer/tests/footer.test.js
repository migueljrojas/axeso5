'use strict';

var Footer = require('../footer');

describe('Footer View', function() {

  beforeEach(function() {
    this.footer = new Footer();
  });

  it('Should run a few assertions', function() {
    expect(this.footer);
  });

});
