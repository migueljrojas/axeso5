'use strict';

// Constructor
var Footer = function() {
  this.name = 'footer';
  console.log('%s module', this.name.toLowerCase());
};

module.exports = Footer;
