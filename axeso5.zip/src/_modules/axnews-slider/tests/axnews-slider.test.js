'use strict';

var AxnewsSlider = require('../axnews-slider');

describe('AxnewsSlider View', function() {

  beforeEach(function() {
    this.axnewsSlider = new AxnewsSlider();
  });

  it('Should run a few assertions', function() {
    expect(this.axnewsSlider);
  });

});
