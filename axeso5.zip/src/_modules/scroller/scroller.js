'use strict';

// Constructor
var Scroller = function() {

};

module.exports = Scroller;
