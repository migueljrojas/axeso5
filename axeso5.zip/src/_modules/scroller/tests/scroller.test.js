'use strict';

var Scroller = require('../scroller');

describe('Scroller View', function() {

  beforeEach(function() {
    this.scroller = new Scroller();
  });

  it('Should run a few assertions', function() {
    expect(this.scroller);
  });

});
