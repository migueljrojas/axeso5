'use strict';

// Constructor
var AxnewsScroller = function() {
    
};

module.exports = AxnewsScroller;
